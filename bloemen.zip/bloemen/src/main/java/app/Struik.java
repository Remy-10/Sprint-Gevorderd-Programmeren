package app;

public class Struik {
    private String bladsoort;

}