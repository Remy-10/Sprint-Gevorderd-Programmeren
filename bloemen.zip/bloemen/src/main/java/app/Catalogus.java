package app;

import java.util.*;
import java.io.File;

public class Catalogus {
    private List<Plant> planten;
    private Map<String,Set<Plant>> overzicht;

    // schrijf hier de constructor

    public Plant getRandomPlantVanMinimaleHoogte(int hoogte) {

        return null; // vervang
    }

    public int aantalStruikenMetBladsoort(String bladsoort) {

        return 0; // vervang
    }

    public Set<Plant> plantenGeordend() {

        return null; // vervang
    }

    public String plantenInKleur(String kleur, int minhoogte, int maxhoogte) {

        return ""; // vervang
    }
}
