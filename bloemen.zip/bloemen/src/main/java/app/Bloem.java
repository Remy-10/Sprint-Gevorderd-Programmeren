package app;

public class Bloem {

    private String kleur;

}