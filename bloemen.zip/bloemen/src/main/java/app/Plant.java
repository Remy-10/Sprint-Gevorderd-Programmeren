package app;

public /*abstract*/ class Plant  {

    private String naam;
    private int hoogte;

    //schrijf hier de constructor; naam en hoogte worden meegegeven


    //schrijf hier de getter voor de hoogte 


    //schrijf hieronder de overige methodes

}

